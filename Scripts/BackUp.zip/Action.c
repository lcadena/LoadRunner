Action()
{

	web_set_max_html_param_len("300000");
	web_set_user("EU.BOEHRINGER.COM\\{User}", 
		lr_unmask("5e5fa6123b1b053c6e3ddbad79405d"), 
		"coraqa.eu.boehringer.com:80");
	
	lr_start_transaction ("01 Login");

	web_url("coraqa.eu.boehringer.com", 
		"URL=http://coraqa.eu.boehringer.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

		web_reg_save_param("Instance", "LB=ctl00_hfInstanceID\" value=\"", "RB=\"", LAST);
		web_reg_save_param("Contract", "LB=href=\"ContentPage.aspx?AgrID=", "RB=\"",  "Ord=All", LAST);
	web_url("App", 
		"URL=http://coraqa.eu.boehringer.com/App", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://coraqa.eu.boehringer.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
			LAST);

		lr_save_string(lr_paramarr_random("Contract"),"contractID");
	lr_end_transaction ("01 Login", LR_AUTO);
	
	lr_start_transaction("02 View Contract");


	web_url("ToolTipEngine.aspx", 
		"URL=http://coraqa.eu.boehringer.com/App/ToolTipEngine.aspx?ToolTipType=GlobalResource&ToolTipContent=CLICKTOTOGGLECONTROL", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://coraqa.eu.boehringer.com/App/MyCarizma.aspx", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);
	
		web_reg_save_param("viewstate", "LB=__VIEWSTATE\" value=\"", "RB=\"", LAST);
		web_reg_save_param("InstanceID", "LB=ctl00_hfInstanceID\" value=\"", "RB=\"", LAST);
		web_reg_save_param("previous", "LB=__PREVIOUSPAGE\" value=\"", "RB=\"", LAST);

	web_url("ContentPage.aspx", 
		"URL=http://coraqa.eu.boehringer.com/App/ContentPage.aspx?AgrID={contractID}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://coraqa.eu.boehringer.com/App/MyCarizma.aspx", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("Heartbeat.aspx", 
		"URL=http://coraqa.eu.boehringer.com/App/Heartbeat.aspx?cleanup=true&instance={Instance}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://coraqa.eu.boehringer.com/App/MyCarizma.aspx", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
			LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("ToolTipEngine.aspx_2", 
		"URL=http://coraqa.eu.boehringer.com/App/ToolTipEngine.aspx?ToolTipType=GlobalResource&ToolTipContent=CLICKTOTOGGLECONTROL", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://coraqa.eu.boehringer.com/App/ContentPage.aspx?AgrID={contractID}", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("02 View Contract", LR_AUTO);

	lr_start_transaction("03 Click Documents");

	web_add_header("X-MicrosoftAjax", 
		"Delta=true");

		lr_replace( "viewstate",
		"/",
		"%2F");
	lr_replace( "viewstate",
		"+",
		"%2B");	
		lr_replace( "viewstate",
		"=",
		"%3D");	
	web_reg_save_param("viewstate2", "LB=|__VIEWSTATE|", "RB=|", LAST);


	web_custom_request("ContentPage.aspx_2", 
		"URL=http://coraqa.eu.boehringer.com/App/ContentPage.aspx?AgrID={contractID}", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://coraqa.eu.boehringer.com/App/ContentPage.aspx?AgrID={contractID}", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=utf-8", 
		"Body=ctl00%24AjaxControlToolkitScriptManager=ctl00%24ContentplaceHolderSidebar%24updatePanelNavTree%7Cctl00%24ContentplaceHolderSidebar%24CaseNavigationTree%24_btnNavTVClick&__EVENTTARGET=&__EVENTARGUMENT=&tvNavigation_ExpandState=nncnnnnncnnncnncnnncnnnnnnnnnnnnnnnnn&tvNavigation_SelectedNode=tvNavigationt2&tvNavigation_PopulateLog=&__VIEWSTATE="
		"{viewstate}&__VIEWSTATEGENERATOR=09F09E4B&__SCROLLPOSITIONX=0&__SCROLLPOSITIONY=0&__PREVIOUSPAGE={previous}&"
		"ctl00%24hfInstanceID={InstanceID}&ctl00%24hfBaseConfig=BI&ctl00%24hfBasePath=http%3A%2F%2Fcoraqa.eu.boehringer.com%2FApp&ctl00%24hfUseHTMLDNDUpload=false&ctl00%24hfDisableExtendedErrorHandling=False&ctl00%24hfRSA_PUBLIC_KEY="
		"-----BEGIN%20PUBLIC%20KEY-----%0AMIGeMA0GCSqGSIb3DQEBAQUAA4GMADCBiAKBgH2YqMIp%2FIg6m1ensZgsPcBFez6L%0AgBj8QsWYAcu00vjoSrQL6C5MMFh4qfP97Vf0qydwrvnC24kwkh7KWzeouUtlauOu%0A1KLBAVUFCIzCA8Qz9BPn5AeMphQK2QHfeALmZEDEWQe9ep90X9rA%2BieQBy6nk6Ru%0AKnn7d%2Br6WTLlCCzrAgMBAAE%3D%0A-----END%20PUBLIC%20KEY-----&ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24txtSearch=&ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24extSearch_ClientState=&"
		"ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24ctl00%24hfActionName=&ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24ctl00%24hfEdit=&ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24ctl00%24hfInfo=&ctl00%24ContentplaceHolderSidebar%24CaseNavigationTree%24__TargetControlInformation="
		"name%3DSUMMARY_separator_visible%3Dtrue_separator_property%3D._separator_pageType%3DAgr_separator_userControl%3DcfAgrSummary.ascx_separator_controlType%3DSINGLE_separator_objectType%3DCarizma.BusinessObjects.Agr_separator_objectID%3D{contractID}_separator_pageObjectType%3DCarizma.BusinessObjects.Agr_separator_pageObjectID%3D{contractID}_separator_parentType%3DAgr&ctl00%24ContentplaceHolderSidebar%24CaseNavigationTree%24__tvNavScrollPos=&__ASYNCPOST=true&"
		"ctl00%24ContentplaceHolderSidebar%24CaseNavigationTree%24_btnNavTVClick=Btn%20for%20UpdatePanel", 
		LAST);

	web_url("ToolTipEngine.aspx_3", 
		"URL=http://coraqa.eu.boehringer.com/App/ToolTipEngine.aspx?ToolTipContent=Comment", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://coraqa.eu.boehringer.com/App/ContentPage.aspx?AgrID={contractID}", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("03 Click Documents",LR_AUTO);

	lr_start_transaction("04 Click Documentation");

	web_add_header("X-MicrosoftAjax", 
		"Delta=true");


		lr_replace( "viewstate2",
		"/",
		"%2F");
	lr_replace( "viewstate2",
		"+",
		"%2B");	
		lr_replace( "viewstate2",
		"=",
		"%3D");	
web_reg_save_param("viewstate3", "LB=|__VIEWSTATE|", "RB=|", LAST);
	web_custom_request("ContentPage.aspx_3", 
		"URL=http://coraqa.eu.boehringer.com/App/ContentPage.aspx?AgrID={contractID}", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://coraqa.eu.boehringer.com/App/ContentPage.aspx?AgrID={contractID}", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=utf-8", 
		"Body=ctl00%24AjaxControlToolkitScriptManager=ctl00%24ContentplaceHolderSidebar%24updatePanelNavTree%7Cctl00%24ContentplaceHolderSidebar%24CaseNavigationTree%24_btnNavTVClick&__PREVIOUSPAGE={previous}&ctl00%24hfInstanceID={InstanceID}&ctl00%24hfBaseConfig=BI&ctl00%24hfBasePath=http%3A%2F%2Fcoraqa.eu.boehringer.com%2FApp&ctl00%24hfUseHTMLDNDUpload=false&"
		"ctl00%24hfDisableExtendedErrorHandling=False&ctl00%24hfRSA_PUBLIC_KEY=-----BEGIN%20PUBLIC%20KEY-----%0AMIGeMA0GCSqGSIb3DQEBAQUAA4GMADCBiAKBgH2YqMIp%2FIg6m1ensZgsPcBFez6L%0AgBj8QsWYAcu00vjoSrQL6C5MMFh4qfP97Vf0qydwrvnC24kwkh7KWzeouUtlauOu%0A1KLBAVUFCIzCA8Qz9BPn5AeMphQK2QHfeALmZEDEWQe9ep90X9rA%2BieQBy6nk6Ru%0AKnn7d%2Br6WTLlCCzrAgMBAAE%3D%0A-----END%20PUBLIC%20KEY-----&ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24txtSearch=&"
		"ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24extSearch_ClientState=&ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24ctl00%24hfActionName=&ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24ctl00%24hfEdit=&ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24ctl00%24hfInfo=&ctl00%24ContentplaceHolderSidebar%24CaseNavigationTree%24__TargetControlInformation="
		"name%3DDOCUMENTS_separator_visible%3Dtrue_separator_property%3DDMSFolder_separator_userControl%3DcfAgrDocument.ascx_separator_pageType%3DAgr_separator_displayChilds%3Dtrue_separator_childPageType%3DAgr_separator_childDisplayProperties%3DName_separator_childDisplayFormat%3D%7B0%3AB%20%7D_separator_childUserControl%3DcfAgrDocument.ascx_separator_pathToVisibleConditionObject%3D._separator_subChildProperty%3DChildFolders_separator_specialObjectFolderHandling%3Dtrue_separator_controlType%3DLIST_separat"
		"or_objectType%3DCarizma.BusinessObjects.Agr_separator_objectID%3D{contractID}_separator_pageObjectID%3D{contractID}_separator_pageObjectType%3DCarizma.BusinessObjects.Agr_separator_parentType%3DAgr&ctl00%24ContentplaceHolderSidebar%24CaseNavigationTree%24__tvNavScrollPos=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24hidSortDirection=asc&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24hidSortField=name&"
		"ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24hfOverrideExistingDocuments=FALSE&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24x=FALSE&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24hfInitDocumentTemplateAskFields=False&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentRefObjectIDType=&"
		"ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentRefObjectIDValue=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentObjectAWFIDType=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentObjectAWFIDValue=&"
		"ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentPredifinedAWFIDType=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentPredifinedAWFIDValue=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentObjectAWFInEditMode=&"
		"ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfChangeApprovalLevel=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24boxScan%24fileName=&__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE="
		"{viewstate2}&__VIEWSTATEGENERATOR=09F09E4B&__SCROLLPOSITIONX=0&__SCROLLPOSITIONY=0&tvNavigation_ExpandState=nnennnnncnnncnncnnncnnnnnnnnnnnnnnnnn&tvNavigation_SelectedNode="
		"tvNavigationt5&tvNavigation_PopulateLog=&__ASYNCPOST=true&ctl00%24ContentplaceHolderSidebar%24CaseNavigationTree%24_btnNavTVClick=Btn%20for%20UpdatePanel", 
		LAST);

	lr_end_transaction("04 Click Documentation",LR_AUTO);

	lr_start_transaction("05 Browse");

	web_revert_auto_header("X-Requested-With");

		web_reg_save_param("viewstate4", "LB=__VIEWSTATE\" value=\"", "RB=\"", LAST);

	web_submit_data("ContentPage.aspx_4", 
		"Action=http://coraqa.eu.boehringer.com/App/ContentPage.aspx?AgrID={contractID}", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"RecContentType=text/html", 
		"Referer=http://coraqa.eu.boehringer.com/App/ContentPage.aspx?AgrID={contractID}", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__PREVIOUSPAGE", "Value={previous}", ENDITEM, 
		"Name=ctl00$hfInstanceID", "Value={InstanceID}", ENDITEM, 
		"Name=ctl00$hfBaseConfig", "Value=BI", ENDITEM, 
		"Name=ctl00$hfBasePath", "Value=http://coraqa.eu.boehringer.com/App", ENDITEM, 
		"Name=ctl00$hfUseHTMLDNDUpload", "Value=false", ENDITEM, 
		"Name=ctl00$hfDisableExtendedErrorHandling", "Value=False", ENDITEM, 
		"Name=ctl00$hfRSA_PUBLIC_KEY", "Value=-----BEGIN PUBLIC KEY-----\r\nMIGeMA0GCSqGSIb3DQEBAQUAA4GMADCBiAKBgH2YqMIp/Ig6m1ensZgsPcBFez6L\r\ngBj8QsWYAcu00vjoSrQL6C5MMFh4qfP97Vf0qydwrvnC24kwkh7KWzeouUtlauOu\r\n1KLBAVUFCIzCA8Qz9BPn5AeMphQK2QHfeALmZEDEWQe9ep90X9rA+ieQBy6nk6Ru\r\nKnn7d+r6WTLlCCzrAgMBAAE=\r\n-----END PUBLIC KEY-----", ENDITEM, 
		"Name=ctl00$ContentplaceHolderSidebar$ucQuickSearch$txtSearch", "Value=", ENDITEM, 
		"Name=ctl00$ContentplaceHolderSidebar$ucQuickSearch$extSearch_ClientState", "Value=", ENDITEM, 
		"Name=ctl00$ContentplaceHolderSidebar$ucQuickSearch$ctl00$hfActionName", "Value=", ENDITEM, 
		"Name=ctl00$ContentplaceHolderSidebar$ucQuickSearch$ctl00$hfEdit", "Value=", ENDITEM, 
		"Name=ctl00$ContentplaceHolderSidebar$ucQuickSearch$ctl00$hfInfo", "Value=", ENDITEM, 
		"Name=ctl00$ContentplaceHolderSidebar$CaseNavigationTree$__TargetControlInformation", "Value=name=Documentation _separator_visible=true_separator_property=._separator_userControl=cfAgrDocument.ascx_separator_pageType=Agr_separator_displayChilds=true_separator_childPageType=Agr_separator_childDisplayProperties=Name_separator_childDisplayFormat={0:B }_separator_childUserControl=cfAgrDocument.ascx_separator_pathToVisibleConditionObject=._separator_subChildProperty="
		"ChildFolders_separator_specialObjectFolderHandling=true_separator_controlType=SINGLE_separator_objectType=Carizma.BusinessObjects.DMSFolder_separator_objectID=792647327718258546_separator_pageObjectID={contractID}_separator_pageObjectType=Carizma.BusinessObjects.Agr_separator_parentType=Agr", ENDITEM, 
		"Name=ctl00$ContentplaceHolderSidebar$CaseNavigationTree$__tvNavScrollPos", "Value=", ENDITEM, 
		"Name=ctl00$ContentplaceHolderMaster$userControl_UI$box_ContainerModeView$UCDocuments$hidSortDirection", "Value=asc", ENDITEM, 
		"Name=ctl00$ContentplaceHolderMaster$userControl_UI$box_ContainerModeView$UCDocuments$hidSortField", "Value=name", ENDITEM, 
		"Name=ctl00$ContentplaceHolderMaster$userControl_UI$box_ContainerModeView$UCDocuments$hfOverrideExistingDocuments", "Value=FALSE", ENDITEM, 
		"Name=ctl00$ContentplaceHolderMaster$userControl_UI$box_ContainerModeView$UCDocuments$x", "Value=FALSE", ENDITEM, 
		"Name=ctl00$ContentplaceHolderMaster$userControl_UI$box_ContainerModeView$UCDocuments$hfInitDocumentTemplateAskFields", "Value=False", ENDITEM, 
		"Name=ctl00$ContentplaceHolderMaster$userControl_UI$box_ContainerModeView$UCDocuments$fileUpload", "Value={DocumentName}", "File=Yes", ENDITEM, 
		"Name=ctl00$ContentplaceHolderMaster$userControl_UI$box_ContainerModeView$UCDocuments$UserControls_ucApproval1$hfCurrentRefObjectIDType", "Value=", ENDITEM, 
		"Name=ctl00$ContentplaceHolderMaster$userControl_UI$box_ContainerModeView$UCDocuments$UserControls_ucApproval1$hfCurrentRefObjectIDValue", "Value=", ENDITEM, 
		"Name=ctl00$ContentplaceHolderMaster$userControl_UI$box_ContainerModeView$UCDocuments$UserControls_ucApproval1$hfCurrentObjectAWFIDType", "Value=", ENDITEM, 
		"Name=ctl00$ContentplaceHolderMaster$userControl_UI$box_ContainerModeView$UCDocuments$UserControls_ucApproval1$hfCurrentObjectAWFIDValue", "Value=", ENDITEM, 
		"Name=ctl00$ContentplaceHolderMaster$userControl_UI$box_ContainerModeView$UCDocuments$UserControls_ucApproval1$hfCurrentPredifinedAWFIDType", "Value=", ENDITEM, 
		"Name=ctl00$ContentplaceHolderMaster$userControl_UI$box_ContainerModeView$UCDocuments$UserControls_ucApproval1$hfCurrentPredifinedAWFIDValue", "Value=", ENDITEM, 
		"Name=ctl00$ContentplaceHolderMaster$userControl_UI$box_ContainerModeView$UCDocuments$UserControls_ucApproval1$hfCurrentObjectAWFInEditMode", "Value=", ENDITEM, 
		"Name=ctl00$ContentplaceHolderMaster$userControl_UI$box_ContainerModeView$UCDocuments$UserControls_ucApproval1$hfChangeApprovalLevel", "Value=", ENDITEM, 
		"Name=ctl00$ContentplaceHolderMaster$userControl_UI$box_ContainerModeView$UCDocuments$boxScan$fileName", "Value=", ENDITEM, 
		"Name=__EVENTTARGET", "Value=ctl00$ContentplaceHolderMaster$PostBackButton", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VIEWSTATE", "Value={viewstate3}", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=09F09E4B", ENDITEM, 
		"Name=__SCROLLPOSITIONX", "Value=0", ENDITEM, 
		"Name=__SCROLLPOSITIONY", "Value=0", ENDITEM, 
		"Name=tvNavigation_ExpandState", "Value=nnennnnncnnncnncnnncnnnnnnnnnnnnnnnnn", ENDITEM, 
		"Name=tvNavigation_SelectedNode", "Value=tvNavigationt5", ENDITEM, 
		"Name=tvNavigation_PopulateLog", "Value=", ENDITEM, 
		LAST);

	web_url("Heartbeat.aspx_2", 
		"URL=http://coraqa.eu.boehringer.com/App/Heartbeat.aspx?cleanup=true&instance={InstanceID}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://coraqa.eu.boehringer.com/App/ContentPage.aspx?AgrID={contractID}", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("ToolTipEngine.aspx_4", 
		"URL=http://coraqa.eu.boehringer.com/App/ToolTipEngine.aspx?ToolTipType=GlobalResource&ToolTipContent=CLICKTOTOGGLECONTROL", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://coraqa.eu.boehringer.com/App/ContentPage.aspx?AgrID={contractID}", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("05 Browse",LR_AUTO);

	lr_start_transaction("06 Save");

	web_add_auto_header("X-MicrosoftAjax", 
		"Delta=true");


lr_replace( "viewstate4",
		"/",
		"%2F");
	lr_replace( "viewstate4",
		"+",
		"%2B");	
		lr_replace( "viewstate4",
		"=",
		"%3D");	

		web_reg_save_param("viewstate5", "LB=|__VIEWSTATE|", "RB=|", LAST);
		
	web_custom_request("ContentPage.aspx_5", 
		"URL=http://coraqa.eu.boehringer.com/App/ContentPage.aspx?AgrID={contractID}", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://coraqa.eu.boehringer.com/App/ContentPage.aspx?AgrID={contractID}", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=utf-8", 
		"Body=ctl00%24AjaxControlToolkitScriptManager=ctl00%24ContentplaceHolderMaster%24updatePanelContentPage%7Cctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24SaveNewDocument&__EVENTTARGET=ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24SaveNewDocument&__EVENTARGUMENT=&tvNavigation_ExpandState=nnennnnncnnncnncnnncnnnnnnnnnnnnnnnnn&tvNavigation_SelectedNode=tvNavigationt5&tvNavigation_PopulateLog=&__VIEWSTATE="
		"{viewstate4}" 
		"&__VIEWSTATEGENERATOR=09F09E4B&__SCROLLPOSITIONX=0&"
		"__SCROLLPOSITIONY=0&__PREVIOUSPAGE={previous}&ctl00%24hfInstanceID={InstanceID}&ctl00%24hfBaseConfig=BI&ctl00%24hfBasePath=http%3A%2F%2Fcoraqa.eu.boehringer.com%2FApp&ctl00%24hfUseHTMLDNDUpload=false&ctl00%24hfDisableExtendedErrorHandling=False&ctl00%24hfRSA_PUBLIC_KEY="
		"-----BEGIN%20PUBLIC%20KEY-----%0AMIGeMA0GCSqGSIb3DQEBAQUAA4GMADCBiAKBgH2YqMIp%2FIg6m1ensZgsPcBFez6L%0AgBj8QsWYAcu00vjoSrQL6C5MMFh4qfP97Vf0qydwrvnC24kwkh7KWzeouUtlauOu%0A1KLBAVUFCIzCA8Qz9BPn5AeMphQK2QHfeALmZEDEWQe9ep90X9rA%2BieQBy6nk6Ru%0AKnn7d%2Br6WTLlCCzrAgMBAAE%3D%0A-----END%20PUBLIC%20KEY-----&ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24txtSearch=&ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24extSearch_ClientState=&"
		"ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24ctl00%24hfActionName=&ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24ctl00%24hfEdit=&ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24ctl00%24hfInfo=&ctl00%24ContentplaceHolderSidebar%24CaseNavigationTree%24__TargetControlInformation="
		"name%3DDocumentation%20_separator_visible%3Dtrue_separator_property%3D._separator_userControl%3DcfAgrDocument.ascx_separator_pageType%3DAgr_separator_displayChilds%3Dtrue_separator_childPageType%3DAgr_separator_childDisplayProperties%3DName_separator_childDisplayFormat%3D%7B0%3AB%20%7D_separator_childUserControl%3DcfAgrDocument.ascx_separator_pathToVisibleConditionObject%3D._separator_subChildProperty%3DChildFolders_separator_specialObjectFolderHandling%3Dtrue_separator_controlType%3DSINGLE_separa"
		"tor_objectType%3DCarizma.BusinessObjects.DMSFolder_separator_objectID%3D792647327718258546_separator_pageObjectID%3D{contractID}_separator_pageObjectType%3DCarizma.BusinessObjects.Agr_separator_parentType%3DAgr&ctl00%24ContentplaceHolderSidebar%24CaseNavigationTree%24__tvNavScrollPos=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24hidSortDirection=asc&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24hidSortField=name&"
		"ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24hfOverrideExistingDocuments=FALSE&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24x=FALSE&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24hfInitDocumentTemplateAskFields=False&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24newDocumentName={DocumentName}&"
		"ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24newDocumentComment=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentRefObjectIDType=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentRefObjectIDValue=&"
		"ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentObjectAWFIDType=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentObjectAWFIDValue=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentPredifinedAWFIDType=&"
		"ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentPredifinedAWFIDValue=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentObjectAWFInEditMode=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfChangeApprovalLevel=&"
		"ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24boxScan%24fileName=&__ASYNCPOST=true&", 
		LAST);

	lr_end_transaction("06 Save",LR_AUTO);

	lr_start_transaction("07 Preview");
	
//		web_reg_save_param("viewstate5", "LB=__VIEWSTATE\" value=\"", "RB=\"", LAST);
	
lr_replace( "viewstate5",
		"/",
		"%2F");
	lr_replace( "viewstate5",
		"+",
		"%2B");	
		lr_replace( "viewstate5",
		"=",
		"%3D");	

	web_custom_request("ContentPage.aspx_6", 
		"URL=http://coraqa.eu.boehringer.com/App/ContentPage.aspx?AgrID={contractID}", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://coraqa.eu.boehringer.com/App/ContentPage.aspx?AgrID={contractID}", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=utf-8", 
		"Body=ctl00%24AjaxControlToolkitScriptManager=ctl00%24ContentplaceHolderMaster%24updatePanelContentPage%7Cctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24viewLink_648532139643125935&__PREVIOUSPAGE={previous}&ctl00%24hfInstanceID={InstanceID}&ctl00%24hfBaseConfig=BI&ctl00%24hfBasePath=http%3A%2F%2Fcoraqa.eu.boehringer.com%2FApp&"
		"ctl00%24hfUseHTMLDNDUpload=false&ctl00%24hfDisableExtendedErrorHandling=False&ctl00%24hfRSA_PUBLIC_KEY=-----BEGIN%20PUBLIC%20KEY-----%0AMIGeMA0GCSqGSIb3DQEBAQUAA4GMADCBiAKBgH2YqMIp%2FIg6m1ensZgsPcBFez6L%0AgBj8QsWYAcu00vjoSrQL6C5MMFh4qfP97Vf0qydwrvnC24kwkh7KWzeouUtlauOu%0A1KLBAVUFCIzCA8Qz9BPn5AeMphQK2QHfeALmZEDEWQe9ep90X9rA%2BieQBy6nk6Ru%0AKnn7d%2Br6WTLlCCzrAgMBAAE%3D%0A-----END%20PUBLIC%20KEY-----&ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24txtSearch=&"
		"ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24extSearch_ClientState=&ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24ctl00%24hfActionName=&ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24ctl00%24hfEdit=&ctl00%24ContentplaceHolderSidebar%24ucQuickSearch%24ctl00%24hfInfo=&ctl00%24ContentplaceHolderSidebar%24CaseNavigationTree%24__TargetControlInformation="
		"name%3DDocumentation%20_separator_visible%3Dtrue_separator_property%3D._separator_userControl%3DcfAgrDocument.ascx_separator_pageType%3DAgr_separator_displayChilds%3Dtrue_separator_childPageType%3DAgr_separator_childDisplayProperties%3DName_separator_childDisplayFormat%3D%7B0%3AB%20%7D_separator_childUserControl%3DcfAgrDocument.ascx_separator_pathToVisibleConditionObject%3D._separator_subChildProperty%3DChildFolders_separator_specialObjectFolderHandling%3Dtrue_separator_controlType%3DSINGLE_separa"
		"tor_objectType%3DCarizma.BusinessObjects.DMSFolder_separator_objectID%3D792647327718258546_separator_pageObjectID%3D{contractID}_separator_pageObjectType%3DCarizma.BusinessObjects.Agr_separator_parentType%3DAgr&ctl00%24ContentplaceHolderSidebar%24CaseNavigationTree%24__tvNavScrollPos=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24hidSortDirection=asc&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24hidSortField=name&"
		"ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24hfOverrideExistingDocuments=FALSE&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24x=FALSE&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24hfInitDocumentTemplateAskFields=False&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentRefObjectIDType=&"
		"ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentRefObjectIDValue=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentObjectAWFIDType=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentObjectAWFIDValue=&"
		"ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentPredifinedAWFIDType=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentPredifinedAWFIDValue=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfCurrentObjectAWFInEditMode=&"
		"ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24UserControls_ucApproval1%24hfChangeApprovalLevel=&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24boxScan%24fileName=&__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE="
		"{viewstate5}&__VIEWSTATEGENERATOR=09F09E4B&"
		"__SCROLLPOSITIONX=0&__SCROLLPOSITIONY=0&tvNavigation_ExpandState=nnennnnncnnncnncnnncnnnnnnnnnnnnnnnnn&tvNavigation_SelectedNode=tvNavigationt5&tvNavigation_PopulateLog=&__ASYNCPOST=true&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24viewLink_648532139643125935.x=-321&ctl00%24ContentplaceHolderMaster%24userControl_UI%24box_ContainerModeView%24UCDocuments%24viewLink_648532139643125935.y=-542.3800048828125", 
		LAST);

	web_revert_auto_header("X-MicrosoftAjax");

	web_revert_auto_header("X-Requested-With");

	lr_think_time(20);

	web_url("Heartbeat.aspx_3", 
		"URL=http://coraqa.eu.boehringer.com/App/Heartbeat.aspx?instance={InstanceID}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://coraqa.eu.boehringer.com/App/ContentPage.aspx?AgrID={contractID}", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("07 Preview",LR_AUTO);

	return 0;
}